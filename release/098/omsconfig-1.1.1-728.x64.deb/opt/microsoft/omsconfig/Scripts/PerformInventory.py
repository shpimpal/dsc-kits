#!/usr/bin/python
import fileinput
import sys
import subprocess
import os
import fcntl
import shutil
import stat
import imp
from xml.dom.minidom import parse
from os.path import basename, dirname, join, realpath, split

# Redirect output to our log file
pathToCurrentScript = realpath(__file__)
pathToCommonScriptsFolder = dirname(pathToCurrentScript)
fullPathDSCLogger = os.path.join(pathToCommonScriptsFolder, 'nxDSCLog.py')
nxDSCLog = imp.load_source('nxDSCLog', fullPathDSCLogger)
logger = nxDSCLog.ConsoleAndFileLogger()
sys.stdout = logger

def usage():
   print("""Usage: PerformInventory.py [OPTIONS]
OPTIONS (case insensitive):
 --InMOF PATH_TO_INVENTORY.MOF
 --OutXML PATH_TO_OUTPUT_REPORT.XML
 --help
""")

def exitWithError(message, errorCode = 1):
    errorMessage = "ERROR from PerformInventory.py: " + message
    print(errorMessage)
    sys.exit(errorCode)

def printVerboseMessage(message):
    verboseMessage = "VERBOSE from PerformInventory.py: " + message
    print(verboseMessage)

Variables = dict()

# Parse command line arguments
args = []
optlist = []

command_line_length = len(sys.argv)
i = 0
inArgument = False
currentArgument = ""
arg = ""
while i < command_line_length:
   arg = sys.argv[i]
   if i == 0:
      # skip the program name
      i += 1
      continue

   if inArgument:
      Variables[currentArgument] = arg
      inArgument = False
   else:
      if arg[0:2] == "--":
         inArgument = True
         currentArgument = arg[2:].lower()
      else:
         # The rest are not options
         args = sys.argv[i:]
         break
   i += 1

if inArgument:
   Variables[currentArgument] = arg

AcceptableOptions = ["inmof", "outxml", "help"]

if "help" in Variables:
   usage()
   sys.exit(0)

optionsValid = True
for arg in Variables.keys():
   if arg.lower() not in AcceptableOptions:
      optionsValid = False
      exitWithError("Error: %s is not a valid option" % arg)

if optionsValid == False:
   usage()
   sys.exit(1)

omi_bindir = "/opt/omi/bin"
omi_sysconfdir = "/etc/opt/omi/conf"
dsc_sysconfdir = omi_sysconfdir + "/omsconfig"
dsc_reportdir = dsc_sysconfdir + "/InventoryReports"
omicli_path = omi_bindir + "/omicli"
temp_report_path = dsc_sysconfdir + "/configuration/Inventory.xml.temp"
report_path = dsc_sysconfdir + "/configuration/Inventory.xml"
inventorylock_path = dsc_sysconfdir + "/inventory_lock"

if "outxml" in Variables:
    report_path = Variables["outxml"]

parameters = []
parameters.append(omicli_path)
parameters.append("iv")
parameters.append("root/oms")
parameters.append("{")
parameters.append("MSFT_DSCLocalConfigurationManager")
parameters.append("}")

if "inmof" in Variables:
    parameters.append("PerformInventoryOOB")
    parameters.append("{")
    parameters.append("InventoryMOFPath")
    parameters.append(Variables["inmof"])
    parameters.append("}")
else:
    parameters.append("PerformInventory")

if len(dsc_sysconfdir) < 10:
    # something has gone wrong with the directory paths. error out before we attempt to remove the entire file system
    exitWithError("Error: Something has gone wrong with the directory paths. Exiting PerformInventory.")

# If inventory lock files already exists update its permissions.
if os.path.isfile(inventorylock_path):
    os.chmod(inventorylock_path , stat.S_IRUSR | stat.S_IWUSR | stat.S_IRGRP | stat.S_IROTH)
    printVerboseMessage("Updated permissions of file: " + inventorylock_path + " to  644")

# open the inventory lock file, this also creates a file if it does not exist so we are using 644 permissions
filehandle = os.open(inventorylock_path, os.O_WRONLY | os.O_CREAT , 0o644)
printVerboseMessage("Opened file: " + inventorylock_path + "with permissions set to 644")
inventory_lock = os.fdopen(filehandle, 'w')

# Acquire inventory file lock
fcntl.flock(inventory_lock, fcntl.LOCK_EX)

os.system("rm -f " + dsc_reportdir + "/*")

p = subprocess.Popen(parameters, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
stdout, stderr = p.communicate()
retval = p.returncode

printVerboseMessage(stdout)
printVerboseMessage(stderr)

# combine reports together
reportFiles = os.listdir(dsc_reportdir)

final_xml_report = '<INSTANCE CLASSNAME="Inventory"><PROPERTY.ARRAY NAME="Instances" TYPE="string" EmbeddedObject="object"><VALUE.ARRAY>'
values = []
for f in reportFiles:
    if not os.path.isfile(dsc_reportdir + "/" + f):
        continue
    d = parse(dsc_reportdir + "/" + f)
    for valueNode in d.getElementsByTagName('VALUE'):
        values.append(valueNode.toxml())

final_xml_report = final_xml_report + "".join(values) + "</VALUE.ARRAY></PROPERTY.ARRAY></INSTANCE>"

with os.fdopen(os.open(temp_report_path, os.O_WRONLY | os.O_CREAT, 0o644), 'w') as filehandle:
  filehandle.write(final_xml_report)

os.system("rm -f " + dsc_reportdir + "/*")
shutil.move(temp_report_path, report_path)

# Release inventory file lock
fcntl.flock(inventory_lock, fcntl.LOCK_UN)
inventory_lock.close()

sys.exit(retval)
