#!/bin/bash

# This is just a stub
# This file will be replaced when the nxOMSAuditdPlugin DSC module is installed

exit 1