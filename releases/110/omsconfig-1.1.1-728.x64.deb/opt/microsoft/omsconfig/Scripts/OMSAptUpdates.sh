#!/bin/bash
apt-get -q update &> /dev/null



